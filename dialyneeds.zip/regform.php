<!DOCTYPE html>
<html lang="en">
<head>
  <title>Daily Needs</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="https://use.fontawesome.com/e8d21bbd8e.js"></script>
  <style>
    /* Remove the navbar's default margin-bottom and rounded borders */ 
    .navbar {
      margin-bottom: 0;
      border-radius: 0;
    }
    
	/* Add a gray background color and some padding to the footer */
    footer {
      background-color: #337ab7;
      padding: 25px;
	  border-color: #337ab7;
      color: #FFFFFF;
    }
    
  .carousel-inner img {
      width: 100%; /* Set width to 100% */
      margin: auto;
      max-height:500px;
  }

  /* Hide the carousel text when the screen is less than 600 pixels wide */
  @media (max-width: 600px) {
    .carousel-caption {
      display: none; 
    }
  }
  </style>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
 <!--    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="index.html"><img src="images/logo1.png" alt="Daily Needs" style="width:100px;height:100px"></a>
     					
   </div> -->
   
     <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
	  <a class="navbar-brand"href="index.html">DailyNeeds</a>
         </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="index.html">Home</a></li>
        <li><a href="#">About Us</a></li>
       <!--  <li><a href="#">Projects</a></li> -->
        <li><a href="contactus.html">Contact Us</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
       <!--  <li><a href="#"><span class="glyphicon glyphicon-log-in"></span> Login</a></li> -->
		  <li><a href="regform.php"><i class="fa fa-user-plus" style="color:red"></i>&nbsp;&nbsp;&nbsp;REGISTER</a></li>
        <li><a href="loginform.php"><i class="fa fa-sign-in" style="color:red"></i>&nbsp;&nbsp;&nbsp;LOGIN</a></li>
        <li><a href="loginform.php"><i class="glyphicon glyphicon-shopping-cart" style="color:red"></i>&nbsp;&nbsp;&nbsp;CART</a></li> 
      </ul>
    </div>
  </div>
</nav>



<div class="container">
  <h2>Register form</h2>
  <form action="regprocess.php" method="post" enctype="multipart/form-data">
    <div class="form-group">
      <label for="email">Username:</label>
      <input type="text" class="form-control" name="username" placeholder="Enter Username">
    </div>
	<div class="form-group">
      <label for="pwd">Password:</label>
      <input type="password" class="form-control" name="password" placeholder="Enter Password">
    </div>
	<div class="form-group">
      <label for="email">Email:</label>
      <input type="email" class="form-control" name="email" placeholder="Enter Email">
    </div>
	<div class="form-group">
      <label for="email">Mobile:</label>
      <input type="number" class="form-control" name="mobile" placeholder="Enter Mobile">
    </div>
	<div class="form-group">
      <label for="email">Address:</label>
      <input type="text" class="form-control" name="address" placeholder="Enter Address">
    </div>
   
    <button type="Register" class="btn btn-success">Submit</button><br><br>
	<?php
error_reporting(0);
 echo $_GET["err"];
 ?>
  </form>
</div>
<br><br><br><br><br><br><br><br>
<footer class="container-fluid navbar-inverse">
 <div class="container text-center">
							Copyright &copy; 2017 <a href="index.html">DailyNeeds</a> &nbsp;| &nbsp;All Rights Reserved
</div>
</footer>

</body>
</html>

